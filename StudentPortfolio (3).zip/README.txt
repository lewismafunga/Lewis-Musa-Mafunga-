
# Student Portfolio

This is a simple student portfolio website created as part of an assignment.

## Structure
- index.html: Main HTML file
- css/style.css: Styles for the website
- js/script.js: JavaScript for interactivity
- images/myphoto.jpg: Image used on the homepage

## Navigation
Open index.html in any browser to view the website.
